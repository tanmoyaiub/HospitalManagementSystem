-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2019 at 06:41 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webtech`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `Serial_No` int(200) NOT NULL,
  `Doctor_Specialization` varchar(100) NOT NULL,
  `Doctor_Name` varchar(100) NOT NULL,
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  `Patient_Name` varchar(200) NOT NULL,
  `Patient_Contact` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`Serial_No`, `Doctor_Specialization`, `Doctor_Name`, `Date`, `Time`, `Patient_Name`, `Patient_Contact`) VALUES
(25, 'Gastro Entrology', 'Aminul', '2019-12-20', '01:00:00', 'Deba', '123456778'),
(26, 'Gastro Entrology', 'Dr.Jhinuk', '2019-12-20', '11:00:00', 'Tonmoy', '01773374244'),
(27, 'Medicine', 'Dr.Ajoy', '2019-12-21', '01:02:00', 'Tiash', '01773374244'),
(28, 'Gastro Entrology', 'Aminul', '2019-12-11', '02:00:00', 'Tisha', '01738427831'),
(29, 'Gastro Entrology', 'Aminul', '2019-12-11', '02:00:00', 'Tonmoy', '01738427831'),
(30, 'Gastro Entrology', 'Aminul', '2019-12-28', '21:00:00', 'Laboni', '0155000000');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `schedule_no` int(50) NOT NULL,
  `specialization` varchar(100) NOT NULL,
  `Doctor_Name` varchar(100) NOT NULL,
  `Date` date NOT NULL,
  `Start` time NOT NULL,
  `End` time NOT NULL,
  `Patient_Name` varchar(200) NOT NULL,
  `Contact` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`schedule_no`, `specialization`, `Doctor_Name`, `Date`, `Start`, `End`, `Patient_Name`, `Contact`) VALUES
(1, 'Gastro Entrology', 'Aminul', '2019-12-11', '01:00:00', '05:00:00', 'Tonmoy', 123456789),
(2, 'Gastro Entrology', 'Aminul', '2019-12-28', '10:00:00', '21:00:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(20) NOT NULL,
  `uname` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `sname` varchar(200) NOT NULL,
  `Role` varchar(10) NOT NULL,
  `Contact` int(50) NOT NULL,
  `Specialization` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `uname`, `password`, `sname`, `Role`, `Contact`, `Specialization`) VALUES
(9, 'Tanmoy24', '16', 'Mohammed Tanmoy', 'Admin', 0, ''),
(15, 'Tisha Alam', '25', 'Samsunnahar Tisha', 'User', 1738427831, ''),
(17, 'deba', '28', 'deba28', 'User', 0, ''),
(18, 'Ruble', '29', 'Ruble29', 'User', 0, ''),
(19, 'Shafi', '18', 'Shafi Lal', 'User', 0, ''),
(20, 'Dr.Shipon', '39', 'Shahinur Rahman Sardar Shipon', 'Doctor', 1738427831, 'Medicin'),
(24, 'supti26', '26', 'Supti Rani', 'User', 0, ''),
(27, 'Aminul40', '40', 'Aminul', 'Doctor', 1738427831, 'Gastro Entrology'),
(28, 'Rasel37', '37', 'Dr.Rasel', 'Doctor', 1926968833, 'Neurology'),
(29, 'Ajoy50', '50', 'Dr.Ajoy', 'Doctor', 155000000, 'Medicine'),
(30, 'Tiash11', '11', 'Tiash Kiron', 'User', 0, ''),
(33, 'Jhinuk34', '34', 'Dr.Jhinuk', 'Doctor', 123546983, 'Gastro Entrology');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`Serial_No`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`schedule_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `Serial_No` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `schedule_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
