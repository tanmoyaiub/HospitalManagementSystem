<?php
	session_start();
	
	//require_once['db.php'];
	
	
	
	if(isset($_COOKIE['uname']) && $_SESSION['role']=='Admin'){
		require_once('../db/myprofilefunction.php');
		$data = viewuser($_COOKIE['uname']);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>

	<h1>Welcome AdminHomePage! <?=$_COOKIE['uname']?></h1> 
	
	<a href="users.php">Users</a> |
	<a href="adduser.php">AddPatient</a>	|
	<a href="addDoctor.php">AddDoctor</a>	|
	<a href="searchDoctor.php">SearchDoctor</a>	|
    <a href="applist.php">AppointmentList</a>|
    <a href="applistAdmin.php">ScheduleList</a>|
    <a href="manageappview.php">ManageAppointment</a>|
	 <a href="myprofile.php?id=<?= $data['id'] ?>">MyProfile</a>|	
	<a href="../php/logout.php">logout</a>

</body>	
</html>


<?php		
	}else{
		header('location: login.php');
	}
?>