<?php
	require_once('../db/db.php');
	
	$term = $_REQUEST['key'];
	$conn = getConnection();
	$sql  = "select * from schedule where Doctor_Name='{$term}'";
	//echo $sql;
	$result = mysqli_query($conn , $sql);
	$row = "<option>Select Date</option>";
	while($text = mysqli_fetch_assoc($result))
	{
		$row .= "<option>".$text['Date']."</option>";
		//echo print_r($text);
	}	
	echo $row;
?>


