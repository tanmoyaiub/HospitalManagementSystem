<?php
	require_once('../db/db.php');
	
	
	$Serial_No = $_GET['s_no'];
			$conn = getConnection();	
			$sql = "select * from appointment where Serial_No = ".$Serial_No;
			//echo $sql;
			$result = mysqli_query($conn,$sql);		
			$view = mysqli_fetch_assoc($result);
				
?>

<!DOCTYPE html>
<html>
<head>
	<title>AppointmentView</title>
</head>
<body>
	<h1>AppointmentView</h1>
	
	<a href="applist.php">Back</a> |
	<a href="../php/logout.php">LogOut</a>
	
			
			<table border="1">
			
				<tr>
					<th>Serial_No</th>
					<td><?php echo $view['Serial_No']; ?></td>
				</tr>
				<tr>
					<th>Doctor Specialization</th>
					<td><?php echo $view['Doctor_Specialization']; ?></td>
				</tr>	
				
				<tr>
					<th>Doctor Name</th>
					<td><?php echo $view['Doctor_Name']; ?></td>
				</tr>
				<tr>
					<th>Date</th>
					<td><?php echo $view['Date']; ?></td>
				</tr>
				
				<tr>
					<th>Time</th>
					<td><?php echo $view['Time']; ?></td>
				</tr>
				<tr>
					<th>Patient_Name</th>
					<td><?php echo $view['Patient_Name']; ?></td>
				</tr>
				<tr>
					<th>Patient_Contact</th>
					<td><?php echo $view['Patient_Contact']; ?></td>
				</tr>
				
				
			</table>
	

</body>
</html>