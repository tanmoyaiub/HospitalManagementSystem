<?php
	if(isset($_COOKIE['uname'])){
		$id		=$_GET['id'];
		
?>

<!DOCTYPE html>
<html>
<head>
	<title>ChangePassword</title>
</head>
<body>
	<h1>Change Your Password</h1>
	
	<a href="home.php">Back</a> |
	<a href="../php/logout.php">LogOut</a>
	
	<form method="POST" action="../db/changepasswordfunction.php?id=<?= $_GET['id']?>">		
			<table>
				
				
				<tr>
					<td><input type="text" name="current" placeholder="Current Password"></td>
				</tr>
				<tr>
					<td><input type="text" name="new" placeholder=" New Password"></td>
				</tr>
				<tr>
					<td><input type="text" name="confirm" placeholder="Confirm Password"></td>
				</tr>
				<tr>
					<td><input type="submit" name="submit" value="change password"></td>
				</tr>
			</table> 
	</form>

</body>
</html>
	<?php }else{
			
		header('location:login.php');
	}
	?>


