<?php
	//session_start();
	require_once('../db/applistAdminfunction.php');
	$data = getAllList();	

?>
<!DOCTYPE html>
<html>
<head>
	<title>AppointmentList</title>
</head>
<body>
	<h2>Appointment List</h2>
	
	<a href="home.php">Back</a> |
	
	<a href="../php/logout.php">LogOut</a>
	
	<table border="1">
		<tr>
			<th>Serial_NO</th>
			<th>DoctorSpecialization</th>
			<th>DoctorName</th>
			<th>Date</th>
			<th>Start_Time</th>
			<th>End_Time</th>
		
			
		</tr>
		
		<?php for($i=0; $i<count($data); $i++) { ?>
		<tr>
		
			<td><?=$data[$i]['schedule_no'/*Database Coloumn name*/];?></td>
			<td><?=$data[$i]['specialization'];?></td>
			<td><?=$data[$i]['Doctor_Name'];?></td>
			<td><?=$data[$i]['Date'];?></td>
			<td><?=$data[$i]['Start'];?></td>
			<td><?=$data[$i]['End'];?></td>
	
		</tr>
		<?php } ?> 
		
	</table>
	
	<!-- <div id="text">Text</div>
	
	<input type="text" name="" method="POST" action="" onkeyup="search(this.value)"/>
	
	<div id="content"></div>
	
	<script type="text/javascript">
	
		function search(val)
			{
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST" , "search.php" , true);
				xhttp.setRequestHeader('Content-type' , 'application/x-www-form-urlencoded');	
				xhttp.send('key='+val);
				
				xhttp.onreadystatechange = function()
				{
					if(this.readyState == 4 && this.status == 200)
					{
						//alert(this.responseText);
						document.getElementById('content').innerHTML = this.responseText;
					}
				};
				
			} 
	
		</script>
		-->
</body>
</html>

