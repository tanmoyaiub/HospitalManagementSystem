<?php
	if(isset($_COOKIE['uname']))
	{
		require_once '../db/bookappfunction.php';
		$specs = getSpecs();
		$docs = array();
		
		if (isset($_GET['spec'])){
			$docs = getDoctor($_GET['spec']);
		}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>
	<h1>Search Doctor</h1>
	
	<a href="userhome.php">Back</a> |
	<a href="../php/logout.php">LogOut</a>
	<hr/>
			<div>
				<b>Doctor Specialization: </b>
				<select  name="dspecial" onchange="fetchSpec(this.value)"">
					<option value="Select Specialization">Select Specialization</option>
					<?php
						foreach($specs as $sp){
							echo '<option>'.ucwords(strtolower($sp)).'</option>';
						}
					?>
				</select>
					<script>
					function fetchSpec(val){
						window.location = "searchDocUser.php?spec=" + val;
					}
					</script>
					<!-- <td><input type="text" name="dspecial"></td> -->
				</div>
				<hr/>
			<table border="1">
				
				<tr>
					<td>Doctor Name</td>
					<td>Specialization</td>
				</tr>
				<?php
							foreach($docs as $doc){
								echo '<tr>';
								echo '<td><a href="viewdocUser.php?id='.$doc['id'].'">'.$doc['sname'].'</a></td>';
								
								echo '<td>'.ucwords(strtolower($doc['Specialization'])).'</td>';
								echo '</tr>';
							}
						?>
				
				
			</table>
		<form>
</body>
</html>
	<?php }else{
			
		header('location:login.php');
	}
		