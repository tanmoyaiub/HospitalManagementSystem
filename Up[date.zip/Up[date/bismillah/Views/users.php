<?php
	session_start();
	
	//require_once['db.php'];
	
	
	
	if(isset($_COOKIE['uname'])){
		require_once('../db/myprofilefunction.php');
		$data = viewuser($_COOKIE['uname']);
?>

<!DOCTYPE html>
<html>
<head>
	<title>UserList</title>
</head>
<body>

	<h1>UsersData</h1> 
	
	
	<a href="userlist.php">PatientList</a> | 
	<a href="doctorlist.php">DoctorList</a> | 
	<a href="home.php">back</a> | 
	<a href="../php/logout.php">logout</a>

</body>	
</html>


<?php		
	}else{
		header('location: login.php');
	}
?>