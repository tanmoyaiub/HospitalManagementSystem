<?php
	//session_start();
	require_once('../db/schedulefunction.php');
	$data = getAllList();	

?>
<!DOCTYPE html>
<html>
<head>
	<title>Schedule</title>
</head>
<body>
	<h2>YourSchedule</h2>
	
	<a href="doctorhome.php">Back</a> |
	
	<a href="../php/logout.php">LogOut</a>
	
	<table border="1">
		<tr>
			<th>Schedule_No</th>
			<th>Specialization</th>
			<th>DoctorName</th>
			<th>Date</th>
			<th>StartTime</th>
			<th>EndTime</th>
			<th>Visit</th>
			
		</tr>
		
		<?php for($i=0; $i<count($data); $i++) { ?>
		<tr>
		
			<td><?=$data[$i]['Doctor_Specialization' /*Database Coloumn name*/];?></td>
			<td><?=$data[$i]['Doctor_Specialization' /*Database Coloumn name*/];?></td>
			<td><?=$data[$i]['Doctor_Name'];?></td>
			<td><?=$data[$i]['Date'];?></td>
			<td><?=$data[$i]['Time'];?></td>
			<td><?=$data[$i]['Patient_Name'];?></td>
		
		</tr>
		<?php } ?> 
		
	</table>
	
	
		
</body>
</html>

