<?php
	require_once('../db/db.php');
	
	$dt = $_REQUEST['date'];
	$dc = $_REQUEST['doc'];
	$conn = getConnection();
	$sql  = "select * from schedule where Doctor_Name='{$dc}' and Date='{$dt}'";
	//echo $sql;
	$result = mysqli_query($conn , $sql);
	$row = "";
	$times = mysqli_fetch_assoc($result);
	$st = strval(substr($times['Start'],0,2));
	$tt = strval(substr($times['End'],0,2)) - $st;
	for ($i=0;$i<=$tt;$i++){
		echo '<option>'.strval($st+$i).':00</option>';
	}
	echo $row;
?>
