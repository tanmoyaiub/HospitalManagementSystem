<?php
	if(isset($_COOKIE['uname']))
	{
		require_once '../db/manageappfunction.php';
		$specs = getSpecs();
		$docs = array();
		
		if (isset($_GET['spec'])){
			$docs = getDoctor($_GET['spec']);
		}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>
	<h1>Create Doctor Schedule</h1>
	
	<a href="home.php">Back</a> |
	<a href="../php/logout.php">LogOut</a>
	
			<form method="POST" action="../php/manageapp.php">
			<table>
				<tr>
					<td>Doctor Specialization</td>
				</tr>
				<tr>	
					<td><select  name="dspecial" onchange="fetchSpec(this.value)">
							<option style="font-size:20px;" value="Select Specialization">Select Specialization</option>
							<?php
								foreach($specs as $sp){
									echo '<option'.(($_GET['spec']==$sp) ? ' selected':'').'>'.$sp.'</option>';
								}
							?>
					</select></td>
					<script>
					function fetchSpec(val){
						window.location = "manageappview.php?spec=" + val;
					}
					</script>
					<!-- <td><input type="text" name="dspecial"></td> -->
				</tr>
				
				
				<tr>
					<td>Doctor Name</td>
				</tr>
				<tr>
				
					<td><select  name="dname">
							<option style="font-size:20px;" value="">Select Doctor</option>
						<?php
							foreach($docs as $doc){
								echo '<option>'.$doc['sname'].'</option>';
							}
						?>
					</select></td>
					
					
					<!-- <td><input type="text" name="dname" ></td> -->
				</tr>
				<tr>
					<td>Date</td>
				</tr>
				<tr>
					<td><input type="date" name="date" ></td>
				</tr>
				<tr>
					<td>Start_Time</td>
				</tr>
				<tr>
					<td><input type="time" name="stime" ></td>
				</tr>
				
				<tr>
					<td>End_Time</td>
				</tr>
				<tr>
					<td><input type="time" name="etime" ></td>
				</tr>
				
				
				<tr>
					<td><input type="submit" name="submit" value="submit"></td>
				</tr>
			</table>
		<form>
</body>
</html>
	<?php }else{
			
		header('location:login.php');
	}
		