<?php
	//session_start();
	require_once('../db/applistfunction.php');
	$data = getAllList();	

?>
<!DOCTYPE html>
<html>
<head>
	<title>AppointmentList</title>
</head>
<body>
	<h2>Appointment List</h2>
	
	<a href="doctorhome.php">Back</a> |
	
	<a href="../php/logout.php">LogOut</a>
	
	<table border="1">
		<tr>
			<th>Serial_NO</th>
			<th>DoctorSpecialization</th>
			<th>DoctorName</th>
			<th>Date</th>
			<th>Time</th>
			
		</tr>
		
		<?php for($i=0; $i<count($data); $i++) { ?>
		<tr>
		
			<td><?=$data[$i]['Serial_No'/*Database Coloumn name*/];?></td>
			<td><?=$data[$i]['Doctor_Specialization'];?></td>
			<td><?=$data[$i]['Doctor_Name'];?></td>
			<td><?=$data[$i]['Date'];?></td>
			<td><?=$data[$i]['Time'];?></td>
	
		</tr>
		<?php } ?> 
		
	</table>
	
	<!-- <div id="text">Text</div>
	
	<input type="text" name="" method="POST" action="" onkeyup="search(this.value)"/>
	
	<div id="content"></div>
	
	<script type="text/javascript">
	
		function search(val)
			{
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST" , "search.php" , true);
				xhttp.setRequestHeader('Content-type' , 'application/x-www-form-urlencoded');	
				xhttp.send('key='+val);
				
				xhttp.onreadystatechange = function()
				{
					if(this.readyState == 4 && this.status == 200)
					{
						//alert(this.responseText);
						document.getElementById('content').innerHTML = this.responseText;
					}
				};
				
			} 
	
		</script>
		-->
</body>
</html>

