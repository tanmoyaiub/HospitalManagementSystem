<?php
	if(isset($_COOKIE['uname']))
	{
		require_once '../db/bookappfunction.php';
		$specs = getSpecs();
		$docs = array();
		
		if (isset($_GET['spec'])){
			$docs = getDoctor($_GET['spec']);
		}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>
	<h1>Book Appointment</h1>
	
	<a href="userhome.php">Back</a> |
	<a href="../php/logout.php">LogOut</a>
	
			<form method="POST" action="../php/bookapp.php">
			<table>
				<tr>
					<td>Doctor Specialization</td>
				</tr>
				<tr>	
					<td><select  name="dspecial" onchange="fetchSpec(this.value)">
							<option style="font-size:20px;" value="Select Specialization">Select Specialization</option>
							<?php
								foreach($specs as $sp){
									echo '<option'.(($_GET['spec']==$sp) ? ' selected':'').'>'.$sp.'</option>';
								}
							?>
					</select></td>
					<script>
					function fetchSpec(val){
						window.location = "bookappview.php?spec=" + val;
					}
					</script>
					<!-- <td><input type="text" name="dspecial"></td> -->
				</tr>
				
				
				<tr>
					<td>Doctor Name</td>
				</tr>
				<tr>
				
					<td><select  name="dname" onchange="search(this.value)" id="dname">
							<option style="font-size:20px;" value="">Select Doctor</option>
						<?php
							foreach($docs as $doc){
								echo '<option>'.$doc['sname'].'</option>';
							}
						?>
					</select></td>
					
					
					<!-- <td><input type="text" name="dname" ></td> -->
				</tr>
				<tr>
					<td>Date</td>
				</tr>
				<tr>
					<td><select name="date" id="date" onchange="ttime(this.value)">
						<option>Select</option>
					</select></td>
				</tr>
				<tr>
					<td>Time</td>
				</tr>
				<tr>
					<td><select name="time" id="sttime"></select></td>
				</tr>
				<tr>
					<td>Patient_Name</td>
				</tr>
				<tr>
					<td><input type="text" name="name" ></td>
				</tr>
				<tr>
					<td>Patient_Contact_NO</td>
				</tr>
				<tr>
					<td><input type="text" name="contact" ></td>
				</tr>
				<tr>
					<td><input type="submit" name="submit" value="submit"></td>
				</tr>
			</table>
		<form>
		<script type="text/javascript">
	
		function search(val)
			{
				if (val=='' || val==null)
					document.getElementById('date').innerHTML = "";
				else{
		
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST" , "../Views/scheddate.php" , true);
				xhttp.setRequestHeader('Content-type' , 'application/x-www-form-urlencoded');	
				xhttp.send('key='+val);
				
				xhttp.onreadystatechange = function()
				{
					if(this.readyState == 4 && this.status == 200)
					{
						//alert(this.responseText);
						document.getElementById('date').innerHTML = this.responseText;
					}
				};}
				
			} 
	
		</script>
		
		<script type="text/javascript">
	
		function ttime(val)
			{
				if (val=='' || val==null)
					document.getElementById('sttime').innerHTML = "";
				else{
		
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST" , "../Views/schedtime.php" , true);
				xhttp.setRequestHeader('Content-type' , 'application/x-www-form-urlencoded');	
				xhttp.send('date='+val+'&doc='+document.getElementById('dname').value);
				
				xhttp.onreadystatechange = function()
				{
					if(this.readyState == 4 && this.status == 200)
					{
						//alert(this.responseText);
						document.getElementById('sttime').innerHTML = this.responseText;
					}
				};}
				
			} 
	
		</script>
</body>
</html>
	<?php }else{
			
		header('location:login.php');
	}
		