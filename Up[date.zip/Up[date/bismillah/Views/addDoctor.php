<?php
	if(isset($_COOKIE['uname']))
	{
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>
	<h1>Add New Doctor</h1>
	
	<a href="home.php">Back</a> |
	<a href="../php/logout.php">LogOut</a>
	
	<form method="POST" action="../php/insertdoctor.php">		
			<table border="0">
			
				<tr>
					<td>Doctor Specialization</td>
				</tr>
				<tr>	
					<td><select  name="dspecial">
							<option style="font-size:20px;" value="Select Specialization">Select Specialization</option>
							
							<option  value="Bariatric & Metabolic Diet And Phyclogy">BARIATRIC AND METABOLIC DIET AND PHYCLOGY</option>
							<option  value="Cardiac Electrophysiology & Heart Failure">CARDIAC ELECTROPHYSIOLOGY AND HEART FAILURE</option>
							<option  value="Gastro Entrology">GASTRO ENTROLOGY</option>
							<option  value="Neurology">NEUROLOGY</option>
							<option  value="Medicine">Medicine</option>
							<option  value="Physical Medicine">PHYSICAL MEDICINE</option>
							<option  value="General And Lap Surgery">GENERAL AND LAP SURGERY</option>
					</select></td>
					<!-- <td><input type="text" name="dspecial"></td> -->
				</tr>
				
				
				<tr>
					<td>UserName:</td>
					
				</tr>
				<tr>
				
					<td><input type="text" name="uname"></td>
				
				</tr>
				
				<tr>
					<td>Password:</td>
					
				</tr>
				<tr>
				
					<td><input type="text" name="password"></td>
				
				</tr>
				
				<tr>
					<td>DoctorName</td>
				</tr>
				<tr>
					<td><input type="text" name="dname" ></td>
				</tr>
			
				<tr>
					<td>Contact_NO</td>
				</tr>
				<tr>
					<td><input type="text" name="contact" ></td>
				</tr>
				
				<tr>
					<td><input type="submit" name="submit" value="submit"></td>
				</tr>
			</table>
	</form>

</body>
</html>
	<?php }else{
			
		header('location:login.php');
	}
		