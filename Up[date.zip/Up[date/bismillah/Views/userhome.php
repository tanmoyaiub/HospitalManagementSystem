 <?php
	session_start();
	if(isset($_COOKIE['uname']) && $_SESSION['role']=='User'){
		require_once('../db/myprofilefunction.php');
		$data = viewuser($_COOKIE['uname']);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>

	<h1>Welcome UserHomePage! <?=$_COOKIE['uname']?></h1> 
	
	<a href="userlistForUser.php">UserList</a> | 
	<a href="searchDocUser.php">SearchYourDoctor</a> | 
	<a href="bookappview.php">BookAppointment</a> |
	<a href="applistUser.php">AppointmentList</a> |
	<a href="myprofileu.php?id=<?= $data['id'] ?>">MyProfile</a> |
	<a href="../php/logout.php">logout</a>

</body>	
</html>


<?php		
	}else{
		header('location: login.php');
	}
?>