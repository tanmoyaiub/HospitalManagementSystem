<?php
	if(isset($_COOKIE['uname']))
	{
?>

<!DOCTYPE html>
<html>
<head>
	<title>MakeYourSchedule</title>
</head>
<body>
	<h1>MakeYourSchedule <?=$_COOKIE['uname']?></h1>
	
	<a href="doctorhome.php">Back</a> |
	<a href="../php/logout.php">LogOut</a>
	
			<form method="POST" action="../php/schedule.php">
			<table border="0">
			
				<tr>
					<td>Doctor Specialization</td>
				</tr>
				<tr>	
					<td><select  name="dspecial">
							<option style="font-size:20px;" value="Select Specialization">Select Specialization</option>
							
							<option style="font-size:20px;" value="BARIATRIC AND METABOLIC DIET AND PHYCLOGY">BARIATRIC AND METABOLIC DIET AND PHYCLOGY</option>
							<option style="font-size:20px;" value="CARDIAC ELECTROPHYSIOLOGY AND HEART FAILURE">CARDIAC ELECTROPHYSIOLOGY AND HEART FAILURE</option>
							<option style="font-size:20px;" value="GASTRO ENTROLOGY">GASTRO ENTROLOGY</option>
							<option style="font-size:20px;" value="NEUROLOGY">NEUROLOGY</option>
							<option style="font-size:20px;" value="PHYSICAL MEDICINE">PHYSICAL MEDICINE</option>
							<option style="font-size:20px;" value="GENERAL AND LAP SURGERY">GENERAL AND LAP SURGERY</option>
					</select></td>
					<!-- <td><input type="text" name="dspecial"></td> -->
				</tr>
				
				
				<tr>
					<td>Doctor Name:</td>
					
				</tr>
				<tr>
				
					<td name="dname"><?=$_COOKIE['uname']?></td>
					
					
					<!-- <td><input type="text" name="dname" ></td> -->
				</tr>
				<tr>
					<td>Date</td>
				</tr>
				<tr>
					<td><input type="date" name="date" ></td>
				</tr>
				<tr>
					<td>StartTime</td>
				</tr>
				<tr>
					<td><input type="time" name="stime" ></td>
				</tr>
				<tr>
					<td>EndTime</td>
				</tr>
				<tr>
					<td><input type="time" name="etime" ></td>
				</tr>
				<tr>
					<td>BreakTime</td>
				</tr>
				<tr>
					<td><input type="time" name="btime" ></td>
				</tr>
			
				<tr>
					<td>Contact_NO</td>
				</tr>
				<tr>
					<td><input type="text" name="contact" ></td>
				</tr>
				<tr>
					<td>Fees</td>
				</tr>
				<tr>
					<td><input type="text" name="fees" ></td>
				</tr>
				<tr>
					<td><input type="submit" name="submit" value="submit"></td>
				</tr>
			</table>
		<form>
</body>
</html>
	<?php }else{
			
		header('location:login.php');
	}
		