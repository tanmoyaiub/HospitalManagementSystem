<?php
	if(isset($_COOKIE['uname']))
	{
			require_once('../db/db.php');
			$Serial_No=$_GET['s_no'];
			$conn 	= getConnection();	
			$sql 	= "select * from appointment where Serial_No=".$Serial_No;
			//echo $sql;
			$result = mysqli_query($conn,$sql);		
			$edit 	= mysqli_fetch_assoc($result);
			print_r($edit);
			
			$sql = "select distinct Specialization from users where Role='Doctor'";
			$result = mysqli_query($conn,$sql);
			$dsp = array();
			while ($row = mysqli_fetch_assoc($result))
				array_push($dsp, $row['Specialization']);
		
			$sql = "select distinct sname from users  where Role='Doctor'";
			$result = mysqli_query($conn,$sql);
			$dna = array();
			while ($row = mysqli_fetch_assoc($result))
				array_push($dna, $row['sname']);
			
			require_once('../db/bookappfunction.php');
			$specs 	= getSpecs();
			$docs	= array();
			
			if(isset($_GET['spec']))
			{
				$docs = getDoctor($_GET['spec']); 
			}
			if(isset($_POST['submit']))
				{
					$dspecial 		= $_POST['dspecial'];	
					$dname 			= $_POST['dname'];
					$date			= $_POST['date'];
					$time			= $_POST['time'];
					$name			= $_POST['name'];
					$contact		= $_POST['contact'];
					
						
					$sql = "UPDATE appointment SET Doctor_Specialization ='{$dspecial}' , Doctor_Name='$dname' , Date='$date' , Time='$time' , Patient_Name='$name' , Patient_Contact='$contact' WHERE Serial_No=".$Serial_No;
					
					mysqli_query($conn , $sql);
					header("location: applist.php?s_no=" .$Serial_No);
						
				}
				
				

?>



<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>
	<h1>Book Appointment</h1>
	
	<a href="home.php">Back</a> |
	<a href="../php/logout.php">LogOut</a>
	
	<form method="POST" action="">		
			<table>
				<tr>
					<td>Doctor Specialization</td>
				</tr>
				<tr>	
					<td><select  name="dspecial" onchange="fetchSpec(this.value)">
					
					<?php
					foreach($dsp as $sp){
						echo '<option'.(($edit['Doctor_Specialization']==$sp)?' selected="selected"':'').'>'.$sp.'</option>';
					}
					?>
					</select></td>
					<!-- <td><input type="text" name="dspecial"></td> -->
					<script>
					function fetchSpec(val){
						window.location='appedit.php?s_no=<?=$_GET['s_no']?>&spec='+val;
					}
					</script>
				</tr>
				
				
				<tr>
					<td>Doctor Name</td>
				</tr>
				<tr>
				
					<td><select  name="dname">
					<?php
					foreach($dna as $sp){
						echo '<option'.(($edit['Doctor_Name']==$sp)?' selected="selected"':'').'>'.$sp.'</option>';
					}
					?>
					</select></td>
					
					
					<!-- <td><input type="text" name="dname" ></td> -->
				</tr>
				<tr>
					<td>Date</td>
				</tr>
				<tr>
					<td><input type="date" name="date" value="<?php echo $edit['Date']; ?>"  ></td>
				</tr>
				<tr>
					<td>Time</td>
				</tr>
				<tr>
					<td><input type="time" name="time" value="<?php echo $edit['Time']; ?>"  ></td>
				</tr>
				<tr>
					<td>Patient_Name</td>
				</tr>
				<tr>
					<td><input type="text" name="name" value="<?php echo $edit['Patient_Name']; ?>"  ></td>
				</tr>
				
				<tr>
					<td>Patient_Contact</td>
				</tr>
				<tr>
					<td><input type="text" name="contact" value="<?php echo $edit['Patient_Contact']; ?>"  ></td>
				</tr>
				
				<tr>
					<td><input type="submit" name="submit" value="submit"></td>
				</tr>
			</table>
	</form>

</body>
</html>
	<?php }else{
			
		header('location:login.php');
	}



















	
	
	
  	