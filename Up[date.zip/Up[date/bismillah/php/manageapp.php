<?php
	require_once('../db/manageappfunction.php');
	
	if(isset($_POST['submit']))
		{
			
			//$serial			= $_GET['serial'];
			$dspecial 		= $_POST['dspecial'];	
			$dname 			= $_POST['dname'];
			$date			= $_POST['date'];
			$stime			= $_POST['stime'];
			$etime			= $_POST['etime'];
			
			
			
			if(empty($dspecial)==true || empty($dname)==true || empty($date)==true || empty($stime)==true || empty($etime)==true)
				{
					echo "null submission";
				}
			else
				{
					$status = book($dspecial , $dname , $date , $stime , $etime);
					
					if($status)
						{
							header('location:../Views/applistAdmin.php');		
						}
						else
						{
							echo "database error";		
						}				
				}
		}
	else
		{
			header('location:../Views/userlist.php');	
		}
		

?>