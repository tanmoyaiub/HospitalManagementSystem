<?php
	require_once('../db/dinsertfunction.php');
	
	if(isset($_POST['submit']))
		{
			$uname 			= $_POST['uname'];	
			$password 		= $_POST['password'];
			$dname			= $_POST['dname'];
			$specialization = $_POST['dspecial'];
			$contact		= $_POST['contact'];
			
			
			if(empty($uname)==true || empty($password)==true || empty($dname)==true || empty($dname)==true || empty($specialization)==true || empty($contact)==true)
				{
					echo "null submission";
				}
			else
				{
					$status = insert($uname , $password , $dname , $specialization , $contact);
					
					if($status)
						{
							header('location:../Views/doctorlist.php');		
						}
						else
						{
							print_r($status);		
						}				
				}
		}
	else
		{
			header('location:../Views/doctorlist.php');	
		}
		

?>