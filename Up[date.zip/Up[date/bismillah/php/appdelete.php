<?php
	require_once('../db/appdeletefunction.php');
	
	if(isset($_GET['s_no']))
	{
		$status = deleteapp($_GET['s_no']);
		
		if($status)
		{
			header('location:../Views/applist.php');	
		}
		else
		{
			echo "Try again";
		}
		
		
	}
	else
	{
		echo "Invalid Request";
	}



?>