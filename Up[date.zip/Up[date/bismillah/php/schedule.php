<?php

	if(isset($_COOKIE['uname']))
	{
	require_once('../db/schedulefunction.php');
	if(isset($_POST['submit']))
	{
		$schedule_no= $_GET['schedule_no'];
		$dspecial 	= $_POST['dspecial'];
		$dname 		= $_POST['dname'];
		$date		= $_POST['date'];
		$stime 		= $_POST['stime'];
		$etime 		= $_POST['etime'];
		$btime 		= $_POST['btime'];
		$contact 	= $_POST['contact'];
		$fees 		= $_POST['fees'];
		
		if( empty($dspecial)==true || empty($date)==true || empty($stime)==true || empty($etime)==true || empty($btime)==true || empty($contact)==true || empty($fees)==true)
		{
			echo "null submission";
		}
		else
		{
			$status = schedule($schedule_no , $dspecial , $dname , $date , $stime , $etime , $btime , $contact , $fees);
			
			if($status)
			{
				header('location:../Views/scheduleList.php');
				
			}
			else{
				
				echo "database error";
			}
			
		}

		
	}
	else
		{
			header('location:../Views/userlist.php');	
		}
	}
	else{
		
		header('location:../Views/login.php');
	}
?>
