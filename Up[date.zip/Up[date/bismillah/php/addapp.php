<?php
	require_once('../db/bookappfunction.php');
	
	if(isset($_POST['submit']))
		{
			
			//$serial			= $_GET['serial'];
			$dspecial 		= $_POST['dspecial'];	
			$dname 			= $_POST['dname'];
			$date			= $_POST['date'];
			$time			= $_POST['time'];
			$name			= $_POST['name'];
			$contact		= $_POST['contact'];
			
			
			if(empty($dspecial)==true || empty($dname)==true || empty($date)==true || empty($time)==true || empty($name)==true || empty($contact)==true)
				{
					echo "null submission";
				}
			else
				{
					$status = book($dspecial , $dname , $date , $time , $name , $contact);
					
					if($status)
						{
							header('location:../Views/applist.php');		
						}
						else
						{
							echo "database error";		
						}				
				}
		}
	else
		{
			header('location:../Views/userlist.php');	
		}
		

?>