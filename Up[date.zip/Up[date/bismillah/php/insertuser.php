<?php
	require_once('../db/insertfunction.php');
	
	if(isset($_POST['submit']))
		{
			$uname 		= $_POST['uname'];	
			$password 	= $_POST['password'];
			$sname		= $_POST['sname'];
			
			
			
			if(empty($uname)==true || empty($password)==true || empty($sname)==true)			
				{
					echo "null submission";
				}
			else
				{
					$status = insert($uname , $password , $sname);
					
					if($status)
						{
							header('location:../Views/userlist.php');		
						}
						else
						{
							print_r($status);		
						}				
				}
		}
	else
		{
			header('location:../Views/userlist.php');	
		}
		

?>