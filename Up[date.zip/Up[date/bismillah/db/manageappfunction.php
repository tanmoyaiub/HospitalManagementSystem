<?php
	require_once('db.php');

	function book($dspecial , $dname, $date, $stime , $etime)
	{
		$conn 	= 	getConnection();	
		$sql	=	"insert into schedule (specialization , Doctor_Name , Date , Start , End) values ('{$dspecial}' , '{$dname}' , '{$date}' , '{$stime}' , '{$etime}')";
		//echo $sql;
		$result = mysqli_query($conn,$sql);
		if($result)
		{
			return true;	
		}else
		{
			return $result;
		}	
	}
		
	function getSpecs(){
		$conn 	= 	getConnection();	
		$sql	=	"select distinct Specialization from users where Role='Doctor'";	
		$specs = array();
		$result = mysqli_query($conn,$sql);
		while($row = mysqli_fetch_assoc($result)){
			array_push($specs, $row['Specialization']);
		}
		return $specs;
	}

	function getDoctor(string $spe){
		$conn 	= 	getConnection();	
		$sql	=	"select * from users where Specialization='{$spe}'";
	
		$specs = array();
		$result = mysqli_query($conn,$sql);
		while($row = mysqli_fetch_assoc($result)){
			array_push($specs, $row);
		}
		return $specs;
		print_r($specs);
	}
?>