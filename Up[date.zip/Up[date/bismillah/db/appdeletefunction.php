<?php
	require_once('db.php');

	function deleteapp($s_no)
	{
		$conn = getConnection();
		$sql  = "delete from appointment where Serial_No=".$s_no;

		if(mysqli_query($conn,$sql))
		{
			return true;		
		}
		else
		{
			return false;		
		}		

	}	
	
?>