<?php
	require_once('../db/db.php');
	
	$term = $_REQUEST['key'];
	$conn = getConnection();
	$sql  = "select * from appointment where (Patient_Name<>'' and Patient_Name like '%{$term}%')";
	//echo $sql;
	$result = mysqli_query($conn , $sql);
	$row = "";
	while($data = mysqli_fetch_assoc($result))
	{
		$row.= '<a href="viewapp.php?s_no='.$data['Serial_No'].'">'.$data['Patient_Name'].'</a><br/>';
		//$row .= ."|".$data['password']."|".$data['sname']."<br>";
	}	
	echo $row;
?>


