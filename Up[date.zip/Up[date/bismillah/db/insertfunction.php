<?php
	require_once('db.php');

	function insert($uname, $password, $sname)
		{
			$conn 	= 	getConnection();	
			$sql	=	"insert into users (uname, password,sname,Role) values('{$uname}','{$password}','{$sname}','User')";
			//echo $sql;
			$res = mysqli_query($conn,$sql);
			
			if($res)
			{
				return true;	
			}else
			{
				return $res;
			}
			
			
			
		}

?>