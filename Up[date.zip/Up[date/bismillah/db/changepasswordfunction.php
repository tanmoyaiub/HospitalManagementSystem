<?php
	require_once('db.php');	
	$id=$_REQUEST['id'];
	$conn 	= getConnection();
	$sql	= "select * from users where id=".$id;
	$result	= mysqli_query($conn , $sql);
	$data	= mysqli_fetch_assoc($result);
			
		$oldpwd = $data['password'];
		
		if(isset($_POST['submit']))
		{
			$current= $_POST['current'];
			$new 	= $_POST['new'];
			$confirm= $_POST['confirm'];
			
			if($current == $oldpwd)
			{
				if($new == $confirm)
				{
					$update = "update users set password = '$new' where id=".$id;
					$res = mysqli_query($conn , $update);
					
					if($res)
					{
							echo "Your password changed successfully";
					}
					else{
						echo "Your both password do not matched";
					}
				}
				
			}
			else
			{
				echo "You entered wrong password";
			}
			
		}
	

?>