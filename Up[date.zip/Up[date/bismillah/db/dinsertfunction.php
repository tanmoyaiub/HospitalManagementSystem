<?php
	require_once('db.php');

	function insert($uname , $password , $dname , $specialization , $contact)
		{
			$conn 	= 	getConnection();	
			$sql	=	"insert into users (uname, password,sname,Role,Contact , Specialization) values('{$uname}','{$password}','{$dname}','Doctor' ,'{$contact}' , '{$specialization}')";
			//echo $sql;
			$res = mysqli_query($conn,$sql);
			
			if($res)
			{
				return true;	
			}else
			{
				return $res;
			}
			
			
			
		}

?>