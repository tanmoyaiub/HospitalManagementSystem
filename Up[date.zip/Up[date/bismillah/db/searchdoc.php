<?php
	require_once('../db/db.php');
	
	$term = $_REQUEST['key'];
	$conn = getConnection();
	$sql  = "select * from users where (Role='Doctor' and uname like '%{$term}%')";
	//echo $sql;
	$result = mysqli_query($conn , $sql);
	$row = "";
	while($data = mysqli_fetch_assoc($result))
	{
		$row.= '<a href="viewdoc.php?id='.$data['id'].'">'.$data['uname'].'</a><br/>';
		//$row .= ."|".$data['password']."|".$data['sname']."<br>";
	}	
	echo $row;
?>


