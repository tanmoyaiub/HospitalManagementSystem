<?php
	require_once('db.php');
	
	
		function viewuser($uname)
		{
			$conn = getConnection();	
			$sql = "select * from users where uname='".$uname."'";
			//echo $sql;
			$result = mysqli_query($conn,$sql);		
			return mysqli_fetch_assoc($result);
			
			/*if($result)
				{
					return true;	
				}
			else
				{
					return false;
				}*/
		}

?> 