<?php
	require_once('db.php');

	function book($dspecial , $dname, $date, $time , $name , $contact)
	{
		$conn 	= 	getConnection();	
		$sql	=	"insert into appointment (Doctor_Specialization , Doctor_Name , Date , Time , Patient_Name , Patient_Contact) values ('{$dspecial}' , '{$dname}' , '{$date}' , '{$time}' , '{$name}' , '{$contact}')";
		//echo $sql;
		$result = mysqli_query($conn,$sql);
		if($result)
		{
			return true;	
		}else
		{
			return $result;
		}	
	}
		
	function getSpecs(){
		$conn 	= 	getConnection();	
		$sql	=	"select distinct Specialization from users where Role='Doctor'";	
		$specs = array();
		$result = mysqli_query($conn,$sql);
		while($row = mysqli_fetch_assoc($result)){
			array_push($specs, $row['Specialization']);
		}
		return $specs;
	}

	function getDoctor(string $spe){
		$conn 	= 	getConnection();	
		$sql	=	"select * from users where Specialization='{$spe}'";
	
		$specs = array();
		$result = mysqli_query($conn,$sql);
		while($row = mysqli_fetch_assoc($result)){
			array_push($specs, $row);
		}
		return $specs;
		print_r($specs);
	}
	

?>