<?php

	require_once('db.php');
	
	function schedule($schedule_no,  $dspecial , $dname , $date , $stime , $etime , $btime , $contact , $fees)
	{
		
		$conn 	= getConnection();
		$sql  	= "insert into schedule (schedule_no , specialization , Doctor_Name , Date , Start , End , Break , Contact , Fees) values ($schedule_no , $dspecial , $dname , $date , $stime , $etime , $btime , $contact , $fees)";
		echo $sql;
		/*$result	=mysqli_query($conn , $sql);
		
		if($result)
		{
			return true;			
		}
		else
		{
			return $result;	
		}*/
		
	}



?>